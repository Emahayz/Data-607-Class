-- Homework 2
-- Q1. Choose six recent popular movies. Ask at least five people that you know 
-- (friends, family, classmates, imaginary friends) to rate each of these movie that they have seen on a scale of 1 to 5. 
-- Take the results (observations) and store them in a SQL database. Load the information into an R dataframe.
-- Your deliverables should include your SQL scripts and your R Markdown code, posted to GitHub.

-- Solution
-- Create a Movie schema then create Movie Table and Reviewers Table within the schema
Drop Table IF EXISTs Movies;
Create Table Movies(
MovieID Int Auto_Increment Primary Key,
Title varchar(50) Not NULL,
Length varchar(180) Not NULL,
URL varchar(200) Not NULL
);

INSERT INTO Movies (MovieID, Title, Length, URL) Values (1, 'Devil Winds', 90, 'https://www.youtube.com/watch?v=pOIQSwB38NM');
INSERT INTO Movies (MovieID, Title, Length, URL) Values (2, 'The Biggest of Oklahoma Tornadoes', 50, 'https://www.youtube.com/watch?v=aULlfbjmKuQ');
INSERT INTO Movies (MovieID, Title, Length, URL) Values (3, 'Tornado Video Classics - Volume Three', 60, 'https://www.youtube.com/watch?v=3Y3MbsorN7M');
INSERT INTO Movies (MovieID, Title, Length, URL) Values (4, 'El Reno Oklahoma Tornado Full Storm Chase', 65, 'https://www.youtube.com/watch?v=3SP5VSwUNDQ');
INSERT INTO Movies (MovieID, Title, Length, URL) Values (5, 'Tornado Video Classics - Volume Two', 70, 'https://www.youtube.com/watch?v=qTPsoDs-rcM');
INSERT INTO Movies (MovieID, Title, Length, URL) Values (6, 'Dirty Deeds', 84, 'https://www.youtube.com/watch?v=5of46VZM7zg');
-- Viewing the Table with contents
Select *
From Movies; 

-- Q2. Ask at least five people that you know to rate each of these movie that they have seen on a scale of 1 to 5.  
-- These should be imaginary reviews that include columns for the user’s name. 
-- the rating is a number between 1 and 5.  
-- There should be a column that links back to the ID column in the table of Movies.

Drop Table IF EXISTS Reviewers;
Create Table Reviewers(
ReviewerID Int Primary Key,
MovieID Int Not NULL References Movies,
ReviewerName varchar(50) Not NULL,
Rating int Not NULL
);

INSERT INTO Reviewers (ReviewerID, MovieID, ReviewerName, Rating) VALUES (21, 1, 'Amos', 3);
INSERT INTO Reviewers (ReviewerID, MovieID, ReviewerName, Rating) VALUES (22, 2, 'Alfred', 5);
INSERT INTO Reviewers (ReviewerID, MovieID, ReviewerName, Rating) VALUES (23, 3,'Gina', 2);
INSERT INTO Reviewers (ReviewerID, MovieID, ReviewerName, Rating) VALUES (24, 4, 'Santos', 3);
INSERT INTO Reviewers (ReviewerID, MovieID, ReviewerName, Rating) VALUES (25, 5, 'McKezie', 5);
INSERT INTO Reviewers (ReviewerID, MovieID, ReviewerName, Rating) VALUES (26, 6,'Gina', 4);
INSERT INTO Reviewers (ReviewerID, MovieID, ReviewerName, Rating) VALUES (27, 2, 'Santos', 5);
INSERT INTO Reviewers (ReviewerID, MovieID, ReviewerName, Rating) VALUES (28, 4, 'McKezie', 3);
Select *
From Reviewers;

-- This is just to Enable me create my connection between MySQL and R
CREATE USER 'movieuser'@'localhost' IDENTIFIED BY 'password';
GRANT SELECT, INSERT, UPDATE, DELETE, EXECUTE, SHOW VIEW ON movieuser.* TO 'movieuser'@'localhost';
ALTER USER 'movieuser'@'localhost' IDENTIFIED WITH mysql_native_password BY 'password';